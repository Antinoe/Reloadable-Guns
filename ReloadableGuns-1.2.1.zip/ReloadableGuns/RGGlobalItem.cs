﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using System.IO;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.Utilities;
using Terraria.ID;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;

namespace ReloadableGuns
{
    public class RGGlobalItem : GlobalItem
    {
        public int AmmoNum;
        public int AmmoMax;
        public int AmmoMax2;
        public override bool InstancePerEntity => true;

        public override GlobalItem Clone(Item item, Item itemClone)
        {
            RGGlobalItem myClone = (RGGlobalItem)base.Clone(item, itemClone);
            myClone.AmmoNum = AmmoNum;
            myClone.AmmoMax = AmmoMax;
            myClone.AmmoMax2 = AmmoMax2;
            return myClone;
        }
        public override void SetDefaults(Item item)
        {
            if (item.ranged = true && item.useAmmo == AmmoID.Bullet)
            {
                AmmoNum = 40;
                AmmoMax = 40;
                AmmoMax2 = AmmoMax;
                item.damage += (int)(item.damage * 0.25f);

                /*if (item.type == ItemID.FlintlockPistol || item.type == ItemID.Musket || item.type == ItemID.TheUndertaker || item.type == ItemID.SniperRifle)
                {
                    AmmoNum = 7;
                    AmmoMax = 7;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.type == ItemID.Boomstick || item.type == ItemID.Revolver || item.type == ItemID.Handgun)
                {
                    AmmoNum = 20;
                    AmmoMax = 20;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.type == ItemID.Minishark || item.type == ItemID.Megashark)
                {
                    AmmoNum = 55;
                    AmmoMax = 55;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.type == ItemID.Xenopopper || item.type == ItemID.VortexBeater)
                {
                    AmmoNum = 100;
                    AmmoMax = 100;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.type == ItemID.ChainGun || item.type == ItemID.SDMG)
                {
                    AmmoNum = 200;
                    AmmoMax = 200;
                    AmmoMax2 = AmmoMax;
                }*/
				if(item.type == ItemID.RedRyder)
                {
                    AmmoNum = 14;
                    AmmoMax = 14;
                    AmmoMax2 = AmmoMax;
                }
				/*else if(item.type == ItemID.FlintlockPistol)
                {
                    AmmoNum = 1;
                    AmmoMax = 1;
                    AmmoMax2 = AmmoMax;
                }
				else if(item.type == ItemID.Musket)
                {
                    AmmoNum = 1;
                    AmmoMax = 1;
                    AmmoMax2 = AmmoMax;
                }*/
				else if(item.type == ItemID.Shotgun)
                {
                    AmmoNum = 4;
                    AmmoMax = 4;
                    AmmoMax2 = AmmoMax;
                }
				else if(item.type == ItemID.TacticalShotgun)
                {
                    AmmoNum = 24;
                    AmmoMax = 24;
                    AmmoMax2 = AmmoMax;
                }
				else if(item.type == ItemID.ClockworkAssaultRifle)
                {
                    AmmoNum = 30;
                    AmmoMax = 30;
                    AmmoMax2 = AmmoMax;
                }
				else if(item.type == ItemID.SniperRifle)
                {
                    AmmoNum = 4;
                    AmmoMax = 4;
                    AmmoMax2 = AmmoMax;
                }
				else if (item.type == ItemID.Boomstick)
                {
                    AmmoNum = 2;
                    AmmoMax = 2;
                    AmmoMax2 = AmmoMax;
                }
				else if (item.type == ItemID.Revolver || item.type == ItemID.TheUndertaker)
                {
                    AmmoNum = 6;
                    AmmoMax = 6;
                    AmmoMax2 = AmmoMax;
                }
				else if (item.useTime <= 1)
                {
                    AmmoNum = 999;
                    AmmoMax = 999;
                    AmmoMax2 = AmmoMax;
                }
				else if (item.useTime <= 2)
                {
                    AmmoNum = 800;
                    AmmoMax = 800;
                    AmmoMax2 = AmmoMax;
                }
				else if (item.useTime <= 3)
                {
                    AmmoNum = 600;
                    AmmoMax = 600;
                    AmmoMax2 = AmmoMax;
                }
				else if (item.useTime <= 4)
                {
                    AmmoNum = 400;
                    AmmoMax = 400;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 5)
                {
                    AmmoNum = 200;
                    AmmoMax = 200;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 6)
                {
                    AmmoNum = 200;
                    AmmoMax = 200;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 7)
                {
                    AmmoNum = 100;
                    AmmoMax = 100;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 8)
                {
                    AmmoNum = 80;
                    AmmoMax = 80;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 9)
                {
                    AmmoNum = 60;
                    AmmoMax = 60;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 10)
                {
                    AmmoNum = 40;
                    AmmoMax = 40;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 15)
                {
                    AmmoNum = 8;
                    AmmoMax = 8;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 20)
                {
                    AmmoNum = 7;
                    AmmoMax = 7;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 25)
                {
                    AmmoNum = 6;
                    AmmoMax = 6;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 30)
                {
                    AmmoNum = 6;
                    AmmoMax = 6;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 35)
                {
                    AmmoNum = 5;
                    AmmoMax = 5;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 40)
                {
                    AmmoNum = 5;
                    AmmoMax = 5;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 45)
                {
                    AmmoNum = 4;
                    AmmoMax = 4;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 50)
                {
                    AmmoNum = 4;
                    AmmoMax = 4;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 55)
                {
                    AmmoNum = 3;
                    AmmoMax = 3;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 60)
                {
                    AmmoNum = 3;
                    AmmoMax = 3;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 65)
                {
                    AmmoNum = 3;
                    AmmoMax = 3;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 70)
                {
                    AmmoNum = 3;
                    AmmoMax = 3;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 75)
                {
                    AmmoNum = 2;
                    AmmoMax = 2;
                    AmmoMax2 = AmmoMax;
                }
                else if (item.useTime <= 80)
                {
                    AmmoNum = 2;
                    AmmoMax = 2;
                    AmmoMax2 = AmmoMax;
                }
            }
        }
        public override bool CanUseItem(Item item, Player player)
        {
            var modplayer = player.GetModPlayer<RGPlayer>();
            if (item.ranged = true && item.useAmmo == AmmoID.Bullet)
            {
                if (AmmoNum <= 0)
                {
					Main.PlaySound(2, (int)player.position.X, (int)player.position.Y, 118);
                    return false;
                }
                else
                {
                    AmmoNum--;
                    if (player.HasBuff(ModContent.BuffType<Buffs.FiringMomentBuff>()))
                    {
                        player.ClearBuff(ModContent.BuffType<Buffs.FiringMomentBuff>());
                    }
                    return true;
                }
            }
            if (player.HeldItem.IsAir)
            {
                return true;
            }
            return base.CanUseItem(item, player);
        }
    }
}
